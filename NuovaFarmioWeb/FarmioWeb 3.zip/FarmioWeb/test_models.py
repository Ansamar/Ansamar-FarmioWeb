from farmiomodels import db, Farmaco, Ordine, create_app

app = create_app()
with app.app_context():
    db.create_all()

    # Aggiungi farmaco di prova
    nuovo_farmaco = Farmaco(
        nome="Aspirina",
        dosaggio="500mg",
        tipo_confezione="compresse",
        quantita_per_confezione=20,
        consumo_giornaliero=2,
        quantita_attuale=20
    )
    db.session.add(nuovo_farmaco)
    db.session.commit()

    # Leggi e stampa farmaci
    farmaci = Farmaco.query.all()
    for f in farmaci:
        print(f"ID: {f.id}, Nome: {f.nome}, Dosaggio: {f.dosaggio}, Quantità attuale: {f.quantita_attuale}")
