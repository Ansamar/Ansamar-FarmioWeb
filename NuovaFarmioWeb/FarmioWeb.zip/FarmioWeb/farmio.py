from flask import Flask, render_template_string, request, redirect, url_for, jsonify
import sqlite3
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# Configurazione database
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'farmio_clean.db')

def format_date(date_string):
    """Formatta una data da stringa SQLite"""
    if not date_string:
        return ""
    try:
        dt = datetime.fromisoformat(date_string.replace('Z', '+00:00'))
        return dt.strftime('%d/%m/%Y')
    except:
        return date_string[:10] if len(date_string) >= 10 else date_string

def init_db():
    """Inizializza il database - versione pulita"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    
    # Tabella farmaci - versione base
    c.execute('''CREATE TABLE IF NOT EXISTS farmaci (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        dosaggio TEXT NOT NULL,
        tipo_confezione TEXT NOT NULL,
        quantita_per_confezione INTEGER NOT NULL,
        consumo_giornaliero REAL NOT NULL,
        quantita_attuale INTEGER DEFAULT 0,
        data_creazione TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Tabella ordini
    c.execute('''CREATE TABLE IF NOT EXISTS ordini (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        farmaco_id INTEGER NOT NULL,
        stato TEXT NOT NULL DEFAULT 'richiesto',
        data_richiesta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_conferma TIMESTAMP NULL,
        data_acquisizione TIMESTAMP NULL,
        quantita_ordinata INTEGER DEFAULT 1,
        note TEXT,
        FOREIGN KEY (farmaco_id) REFERENCES farmaci (id)
    )''')
    
    conn.commit()
    conn.close()

def get_db_connection():
    """Ottieni connessione al database"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def calcola_giorni_rimanenti(quantita_attuale, consumo_giornaliero):
    """Calcola i giorni rimanenti per un farmaco"""
    if consumo_giornaliero <= 0:
        return 99999
    return quantita_attuale / consumo_giornaliero

# Template HTML per la dashboard
DASHBOARD_TEMPLATE = '''
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmioWeb - Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .dashboard-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .farmaco-card { border-left: 5px solid #4CAF50; }
        .farmaco-card.critico { border-left-color: #f44336; }
        .farmaco-card.attenzione { border-left-color: #ff9800; }
        .status-badge { padding: 5px 10px; border-radius: 15px; color: white; font-size: 12px; }
        .status-ok { background-color: #4CAF50; }
        .status-attenzione { background-color: #ff9800; }
        .status-critico { background-color: #f44336; }
        .btn { padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn:hover { background: #5a67d8; }
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        .navigation { margin-bottom: 20px; }
        .navigation a { margin-right: 15px; }
        .giorni-rimanenti { font-size: 24px; font-weight: bold; }
        .farmaco-info { margin-bottom: 10px; }
        .farmaco-nome { font-size: 18px; font-weight: bold; color: #333; }
        .farmaco-dettagli { color: #666; margin: 5px 0; }
        .farmaco-actions { margin-top: 15px; display: flex; gap: 10px; flex-wrap: wrap; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏥 FarmioWeb</h1>
            <p>Dashboard di controllo scorte e ordini farmaci</p>
        </div>
        
        <div class="navigation">
            <a href="/" class="btn">Dashboard</a>
            <a href="/nuovo-farmaco" class="btn">Nuovo Farmaco</a>
            <a href="/ordini" class="btn">Gestione Ordini</a>
        </div>
        
        <div class="dashboard-cards">
            {% for farmaco in farmaci %}
            <div class="card farmaco-card {% if farmaco.giorni_rimanenti <= 3 %}critico{% elif farmaco.giorni_rimanenti <= 7 %}attenzione{% endif %}">
                <div class="farmaco-info">
                    <div class="farmaco-nome">{{ farmaco.nome }}</div>
                    <div class="farmaco-dettagli">{{ farmaco.dosaggio }} • {{ farmaco.tipo_confezione }}</div>
                    <div class="farmaco-dettagli">Consumo: {{ farmaco.consumo_giornaliero }}/giorno</div>
                    <div class="farmaco-dettagli">Scorte attuali: {{ farmaco.quantita_attuale }} {{ farmaco.tipo_confezione }}</div>
                </div>
                
                <div class="giorni-rimanenti">
                    {% if farmaco.giorni_rimanenti > 9999 %}
                        ∞ giorni
                    {% else %}
                        {{ "%.1f"|format(farmaco.giorni_rimanenti) }} giorni
                    {% endif %}
                </div>
                
                <span class="status-badge 
                    {% if farmaco.giorni_rimanenti <= 3 %}status-critico
                    {% elif farmaco.giorni_rimanenti <= 7 %}status-attenzione
                    {% else %}status-ok{% endif %}">
                    {% if farmaco.giorni_rimanenti <= 3 %}CRITICO
                    {% elif farmaco.giorni_rimanenti <= 7 %}ATTENZIONE
                    {% else %}OK{% endif %}
                </span>
                
                <div class="farmaco-actions">
                    <a href="/ordini/{{farmaco.id}}" class="btn">Gestisci Ordini</a>
                    <button onclick="eliminaFarmaco({{farmaco.id}}, '{{farmaco.nome}}')" class="btn btn-danger">Elimina</button>
                </div>
            </div>
            {% endfor %}
        </div>
        
        {% if not farmaci %}
        <div class="card" style="text-align: center; padding: 40px;">
            <h3>Nessun farmaco inserito</h3>
            <p>Inizia aggiungendo il tuo primo farmaco</p>
            <a href="/nuovo-farmaco" class="btn">Aggiungi Farmaco</a>
        </div>
        {% endif %}
    </div>
    
    <script>
        function eliminaFarmaco(id, nome) {
            if (confirm('⚠️ ATTENZIONE!\\n\\nSei sicuro di voler eliminare il farmaco "' + nome + '"?\\n\\nQuesta azione eliminerà anche tutti gli ordini associati e NON può essere annullata!')) {
                if (confirm('Conferma definitivamente l\\'eliminazione di "' + nome + '"?')) {
                    window.location.href = '/elimina-farmaco/' + id;
                }
            }
        }
    </script>
</body>
</html>
'''

# Template per nuovo farmaco
NUOVO_FARMACO_TEMPLATE = '''
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmioWeb - Nuovo Farmaco</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 600px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        .btn { padding: 12px 24px; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: #5a67d8; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>➕ Nuovo Farmaco</h1>
        </div>
        
        <div class="card">
            <form method="POST">
                <div class="form-group">
                    <label for="nome">Nome Farmaco:</label>
                    <input type="text" id="nome" name="nome" placeholder="es: Aspirina" required>
                </div>
                
                <div class="form-group">
                    <label for="dosaggio">Dosaggio:</label>
                    <input type="text" id="dosaggio" name="dosaggio" placeholder="es: 20mg" required>
                </div>
                
                <div class="form-group">
                    <label for="tipo_confezione">Tipo Confezione:</label>
                    <select id="tipo_confezione" name="tipo_confezione" required>
                        <option value="">Seleziona...</option>
                        <option value="capsule">Capsule</option>
                        <option value="compresse">Compresse</option>
                        <option value="gocce">Gocce</option>
                        <option value="fiale">Fiale</option>
                        <option value="ml">Millilitri</option>
                        <option value="altro">Altro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="quantita_per_confezione">Quantità per Confezione:</label>
                    <input type="number" id="quantita_per_confezione" name="quantita_per_confezione" min="1" required>
                </div>
                
                <div class="form-group">
                    <label for="consumo_giornaliero">Consumo Giornaliero:</label>
                    <input type="number" id="consumo_giornaliero" name="consumo_giornaliero" step="0.1" min="0.1" required>
                </div>
                
                <div class="form-group">
                    <label for="quantita_attuale">Quantità Attuale (opzionale):</label>
                    <input type="number" id="quantita_attuale" name="quantita_attuale" min="0" value="0">
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn">Salva Farmaco</button>
                    <a href="/" class="btn btn-secondary" style="margin-left: 10px;">Annulla</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
'''

# Template per gestione ordini
ORDINI_TEMPLATE = '''
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmioWeb - Ordini{{ " - " + farmaco.nome if farmaco else "" }}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .btn { padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin-right: 10px; }
        .btn:hover { background: #5a67d8; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-warning:hover { background: #e0a800; }
        .ordine-timeline { display: flex; align-items: center; margin: 15px 0; }
        .timeline-step { flex: 1; text-align: center; position: relative; }
        .timeline-step.completed { color: #28a745; font-weight: bold; }
        .timeline-step.active { color: #ffc107; font-weight: bold; }
        .timeline-step::after { content: '→'; position: absolute; right: -20px; color: #ccc; }
        .timeline-step:last-child::after { display: none; }
        .form-inline { display: flex; gap: 10px; align-items: center; margin-top: 10px; }
        .form-inline input { padding: 5px; border: 1px solid #ddd; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Gestione Ordini</h1>
            {% if farmaco %}
            <p>{{ farmaco.nome }} - {{ farmaco.dosaggio }}</p>
            {% endif %}
        </div>
        
        <div style="margin-bottom: 20px;">
            <a href="/" class="btn">Dashboard</a>
            {% if farmaco %}
            <a href="/ordini" class="btn">Tutti gli Ordini</a>
            {% endif %}
        </div>
        
        {% if farmaco %}
        <div class="card">
            <h3>Nuovo Ordine</h3>
            <form method="POST" action="/ordini/{{farmaco.id}}/nuovo">
                <div class="form-inline">
                    <label>Quantità confezioni:</label>
                    <input type="number" name="quantita" value="1" min="1" required>
                    <input type="text" name="note" placeholder="Note (opzionale)">
                    <button type="submit" class="btn">Crea Ordine</button>
                </div>
            </form>
        </div>
        {% endif %}
        
        {% for ordine in ordini %}
        <div class="card">
            <h3>{{ ordine.farmaco_nome }} - {{ ordine.farmaco_dosaggio }}</h3>
            <p><strong>Quantità:</strong> {{ ordine.quantita_ordinata }} confezioni</p>
            {% if ordine.note %}<p><strong>Note:</strong> {{ ordine.note }}</p>{% endif %}
            
            <div class="ordine-timeline">
                <div class="timeline-step {% if ordine.data_richiesta %}completed{% endif %}">
                    <div>Richiesto</div>
                    <small>{{ format_date(ordine.data_richiesta) }}</small>
                </div>
                <div class="timeline-step {% if ordine.data_conferma %}completed{% elif ordine.stato == 'confermato' or ordine.stato == 'acquisito' %}active{% endif %}">
                    <div>Confermato</div>
                    <small>{{ format_date(ordine.data_conferma) }}</small>
                </div>
                <div class="timeline-step {% if ordine.data_acquisizione %}completed{% elif ordine.stato == 'acquisito' %}active{% endif %}">
                    <div>Acquisito</div>
                    <small>{{ format_date(ordine.data_acquisizione) }}</small>
                </div>
            </div>
            
            <div style="margin-top: 15px;">
                {% if ordine.stato == 'richiesto' %}
                <form method="POST" action="/ordini/{{ordine.id}}/conferma" style="display: inline;">
                    <button type="submit" class="btn btn-warning">Conferma Ordine</button>
                </form>
                {% endif %}
                
                {% if ordine.stato == 'confermato' %}
                <form method="POST" action="/ordini/{{ordine.id}}/acquisisci" style="display: inline;">
                    <button type="submit" class="btn btn-success">Acquisisci</button>
                </form>
                {% endif %}
            </div>
        </div>
        {% endfor %}
        
        {% if not ordini %}
        <div class="card" style="text-align: center; padding: 40px;">
            <h3>Nessun ordine presente</h3>
            {% if farmaco %}
            <p>Crea il primo ordine per {{ farmaco.nome }}</p>
            {% else %}
            <p>Non ci sono ordini nel sistema</p>
            {% endif %}
        </div>
        {% endif %}
    </div>
</body>
</html>
'''

@app.route('/')
def dashboard():
    """Dashboard principale"""
    conn = get_db_connection()
    farmaci = conn.execute('''
        SELECT id, nome, dosaggio, tipo_confezione, quantita_per_confezione, 
               consumo_giornaliero, quantita_attuale
        FROM farmaci
        ORDER BY nome
    ''').fetchall()
    conn.close()
    
    # Calcola giorni rimanenti per ogni farmaco
    farmaci_data = []
    for farmaco in farmaci:
        giorni_rimanenti = calcola_giorni_rimanenti(farmaco['quantita_attuale'], farmaco['consumo_giornaliero'])
        farmaci_data.append({
            'id': farmaco['id'],
            'nome': farmaco['nome'],
            'dosaggio': farmaco['dosaggio'],
            'tipo_confezione': farmaco['tipo_confezione'],
            'quantita_per_confezione': farmaco['quantita_per_confezione'],
            'consumo_giornaliero': farmaco['consumo_giornaliero'],
            'quantita_attuale': farmaco['quantita_attuale'],
            'giorni_rimanenti': giorni_rimanenti
        })
    
    return render_template_string(DASHBOARD_TEMPLATE, farmaci=farmaci_data)

@app.route('/nuovo-farmaco', methods=['GET', 'POST'])
def nuovo_farmaco():
    """Pagina per aggiungere un nuovo farmaco"""
    if request.method == 'POST':
        nome = request.form['nome']
        dosaggio = request.form['dosaggio']
        tipo_confezione = request.form['tipo_confezione']
        quantita_per_confezione = int(request.form['quantita_per_confezione'])
        consumo_giornaliero = float(request.form['consumo_giornaliero'])
        quantita_attuale = int(request.form.get('quantita_attuale', 0))
        
        conn = get_db_connection()
        conn.execute('''
            INSERT INTO farmaci (nome, dosaggio, tipo_confezione, quantita_per_confezione, 
                               consumo_giornaliero, quantita_attuale)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (nome, dosaggio, tipo_confezione, quantita_per_confezione, 
              consumo_giornaliero, quantita_attuale))
        conn.commit()
        conn.close()
        
        return redirect(url_for('dashboard'))
    
    return render_template_string(NUOVO_FARMACO_TEMPLATE)

@app.route('/ordini')
@app.route('/ordini/<int:farmaco_id>')
def gestione_ordini(farmaco_id=None):
    """Gestione ordini"""
    conn = get_db_connection()
    
    farmaco = None
    if farmaco_id:
        farmaco = conn.execute('SELECT * FROM farmaci WHERE id = ?', (farmaco_id,)).fetchone()
    
    # Query per gli ordini
    if farmaco_id:
        ordini = conn.execute('''
            SELECT o.*, f.nome as farmaco_nome, f.dosaggio as farmaco_dosaggio
            FROM ordini o
            JOIN farmaci f ON o.farmaco_id = f.id
            WHERE o.farmaco_id = ?
            ORDER BY o.data_richiesta DESC
        ''', (farmaco_id,)).fetchall()
    else:
        ordini = conn.execute('''
            SELECT o.*, f.nome as farmaco_nome, f.dosaggio as farmaco_dosaggio
            FROM ordini o
            JOIN farmaci f ON o.farmaco_id = f.id
            ORDER BY o.data_richiesta DESC
        ''').fetchall()
    
    conn.close()
    
    return render_template_string(ORDINI_TEMPLATE, farmaco=farmaco, ordini=ordini)

@app.route('/ordini/<int:farmaco_id>/nuovo', methods=['POST'])
def nuovo_ordine(farmaco_id):
    """Crea un nuovo ordine"""
    quantita = int(request.form['quantita'])
    note = request.form.get('note', '')
    
    conn = get_db_connection()
    conn.execute('''
        INSERT INTO ordini (farmaco_id, quantita_ordinata, note)
        VALUES (?, ?, ?)
    ''', (farmaco_id, quantita, note))
    conn.commit()
    conn.close()
    
    return redirect(url_for('gestione_ordini', farmaco_id=farmaco_id))

@app.route('/ordini/<int:ordine_id>/conferma', methods=['POST'])
def conferma_ordine(ordine_id):
    """Conferma un ordine"""
    conn = get_db_connection()
    conn.execute('''
        UPDATE ordini 
        SET stato = 'confermato', data_conferma = CURRENT_TIMESTAMP 
        WHERE id = ?
    ''', (ordine_id,))
    conn.commit()
    
    ordine = conn.execute('SELECT farmaco_id FROM ordini WHERE id = ?', (ordine_id,)).fetchone()
    conn.close()
    
    return redirect(url_for('gestione_ordini', farmaco_id=ordine['farmaco_id']))

@app.route('/ordini/<int:ordine_id>/acquisisci', methods=['POST'])
def acquisisci_ordine(ordine_id):
    """Acquisisce un ordine (aggiorna anche le scorte)"""
    conn = get_db_connection()
    
    # Ottieni dettagli ordine
    ordine = conn.execute('''
        SELECT o.*, f.quantita_per_confezione
        FROM ordini o
        JOIN farmaci f ON o.farmaco_id = f.id
        WHERE o.id = ?
    ''', (ordine_id,)).fetchone()
    
    # Aggiorna stato ordine
    conn.execute('''
        UPDATE ordini 
        SET stato = 'acquisito', data_acquisizione = CURRENT_TIMESTAMP 
        WHERE id = ?
    ''', (ordine_id,))
    
    # Aggiorna scorte farmaco
    quantita_da_aggiungere = ordine['quantita_ordinata'] * ordine['quantita_per_confezione']
    conn.execute('''
        UPDATE farmaci 
        SET quantita_attuale = quantita_attuale + ?
        WHERE id = ?
    ''', (quantita_da_aggiungere, ordine['farmaco_id']))
    
    conn.commit()
    conn.close()
    
    return redirect(url_for('gestione_ordini', farmaco_id=ordine['farmaco_id']))

@app.route('/elimina-farmaco/<int:farmaco_id>')
def elimina_farmaco(farmaco_id):
    """Elimina un farmaco e tutti i suoi ordini"""
    conn = get_db_connection()
    
    farmaco = conn.execute('SELECT nome FROM farmaci WHERE id = ?', (farmaco_id,)).fetchone()
    
    if farmaco:
        conn.execute('DELETE FROM ordini WHERE farmaco_id = ?', (farmaco_id,))
        conn.execute('DELETE FROM farmaci WHERE id = ?', (farmaco_id,))
        conn.commit()
    
    conn.close()
    
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    print("🚀 Avviando FarmioWeb (versione stabile)...")
    print("📊 Inizializzazione database...")
    
    # Inizializza il database
    init_db()
    
    print("✅ Database inizializzato")
    print("🌐 FarmioWeb disponibile su: http://localhost:8081")
    print("⏹️  Premi CTRL+C per fermare il server")
    
    # Registra la funzione nel contesto del template
    app.jinja_env.globals.update(format_date=format_date)
    
    # Avvia l'app
    app.run(debug=True, host='127.0.0.1', port=8081)